def root(number, root_value):
    f = 1 / root_value
    return number ** f
